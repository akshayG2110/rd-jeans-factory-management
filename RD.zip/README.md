﻿# rd-jeans-factory-management
# RD Jeans Factory Management System

A modern, full-stack Factory Management ERP built for garment and denim manufacturing businesses. The system streamlines daily factory operations, including employee management, payroll, inventory, production tracking, accounting, and business reporting through a secure, responsive web application.

## Features

* 🔐 Secure JWT Authentication & Authorization
* 👨‍🏭 Employee Management
* 💰 Salary & Advance (Upad) Management
* 📦 Denim Roll & Fabric Inventory
* ✂️ Cutting Lot & Production Tracking
* 💵 Income & Expense Management
* 📒 Cashbook & General Ledger
* 🤝 Partner Account Management
* 📊 Interactive Dashboard & Analytics
* 📄 Professional PDF Reports
* 📈 Excel Report Export
* 🔍 Advanced Search & Filtering
* 📱 Responsive UI for Desktop & Mobile
* ⚡ Real-Time Data Synchronization
* 🛡️ Production-Ready Security & Validation

## Technology Stack

### Frontend

* Next.js
* React
* TypeScript
* Tailwind CSS
* Shadcn/UI

### Backend

* FastAPI
* Python
* SQLAlchemy
* Pydantic

### Database

* PostgreSQL

### Authentication

* JWT Authentication
* Bcrypt Password Hashing

### Reports

* ReportLab (PDF)
* OpenPyXL (Excel)

## Core Modules

* Dashboard
* Employee Management
* Salary Management
* Advance (Upad) Management
* Roll Inventory
* Cutting Management
* Income Management
* Expense Management
* Cashbook
* Partner Ledger
* Reports Center

## Highlights

* Enterprise-grade architecture
* Secure REST API
* Dynamic report generation
* Passbook-style accounting reports
* Modular and scalable codebase
* Clean UI/UX
* Optimized database queries
* Role-based authentication ready
* Production deployment ready

## Installation

```bash
git clone https://github.com/YOUR_USERNAME/rd-jeans-factory-management.git

cd rd-jeans-factory-management
```

### Frontend

```bash
npm install
npm run dev
```

### Backend

```bash
cd backend

python -m venv venv

venv\Scripts\activate

pip install -r requirements.txt

uvicorn app.main:app --reload
```

## Project Status

✅ Active Development

This project is continuously improved with new features, performance optimizations, security enhancements, and production-ready best practices.

## License

This project is intended for educational and business use. Please review the license before commercial distribution.
