# core init
